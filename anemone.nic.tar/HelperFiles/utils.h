static struct Utils
{
    unsigned long long cryptBases[2] = {@@CBONE@@, @@CBTWO@@};
} _utils;
